import boto3
import smtplib
import os
import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def get_previous_month_dates():
    today = datetime.date.today()
    first_day_this_month = today.replace(day=1)
    last_day_prev_month = first_day_this_month - datetime.timedelta(days=1)
    first_day_prev_month = last_day_prev_month.replace(day=1)
    return first_day_prev_month.strftime('%Y-%m-%d'), first_day_this_month.strftime('%Y-%m-%d')

def get_aws_cost():
    ce = boto3.client('ce')
    start_date, end_date = get_previous_month_dates()
    response = ce.get_cost_and_usage(
        TimePeriod={'Start': start_date, 'End': end_date},
        Granularity='MONTHLY',
        Metrics=['UnblendedCost']
    )
    cost = response['ResultsByTime'][0]['Total']['UnblendedCost']['Amount']
    return float(cost), start_date, end_date

def get_ec2_resources():
    ec2 = boto3.client('ec2')
    
    # 1. Running EC2 Instances
    instances_info = []
    inst_response = ec2.describe_instances(Filters=[{'Name': 'instance-state-name', 'Values': ['running']}])
    for res in inst_response['Reservations']:
        for inst in res['Instances']:
            name = next((tag['Value'] for tag in inst.get('Tags', []) if tag['Key'] == 'Name'), "Unknown Name")
            instances_info.append(f"  - {name} ({inst['InstanceId']}) | Type: {inst['InstanceType']}")
            
    # 2. EBS Volumes (Flagging available/unattached ones)
    vol_response = ec2.describe_volumes()
    total_vols = len(vol_response['Volumes'])
    unattached_vols = [v for v in vol_response['Volumes'] if v['State'] == 'available']
    
    # 3. EBS Snapshots
    snap_response = ec2.describe_snapshots(OwnerIds=['self'])
    total_snaps = len(snap_response['Snapshots'])
    
    # 4. Elastic IPs (Flagging unassociated ones)
    eip_response = ec2.describe_addresses()
    total_eips = len(eip_response['Addresses'])
    unassociated_eips = [eip for eip in eip_response['Addresses'] if 'InstanceId' not in eip]

    return {
        "instances": instances_info,
        "volumes_total": total_vols,
        "volumes_unattached": len(unattached_vols),
        "snapshots_total": total_snaps,
        "eips_total": total_eips,
        "eips_unassociated": len(unassociated_eips)
    }

def get_s3_resources():
    s3 = boto3.client('s3')
    response = s3.list_buckets()
    buckets = response.get('Buckets', [])
    bucket_info = [f"  - {b['Name']} (Created: {b['CreationDate'].strftime('%Y-%m-%d')})" for b in buckets]
    return bucket_info

def lambda_handler(event, context):
    # Securely load credentials from Lambda Environment Variables
    sender_email = os.environ.get('SENDER_EMAIL')
    app_password = os.environ.get('APP_PASSWORD')
    recipient_email = os.environ.get('RECIPIENT_EMAIL')
    
    # Failsafe check
    if not sender_email or not app_password or not recipient_email:
        print("ERROR: Missing Environment Variables")
        return {"statusCode": 500, "body": "Missing environment variables."}

    # Fetch Cost
    try:
        total_cost, start_date, end_date = get_aws_cost()
        cost_report = f"💰 Total AWS Cost ({start_date} to {end_date}): ${total_cost:.2f}\n"
    except Exception as e:
        cost_report = f"⚠️ Error fetching cost: {str(e)}\n"

    # Fetch EC2, Volumes, Snapshots, EIPs
    try:
        ec2_data = get_ec2_resources()
        inst_text = "\n".join(ec2_data['instances']) if ec2_data['instances'] else "  - None found."
        
        ec2_report = f"""
🟢 Running EC2 Instances:
{inst_text}

💾 EBS Volumes: {ec2_data['volumes_total']} Total
  - ⚠️ UNATTACHED (Wasting Money): {ec2_data['volumes_unattached']}

📸 EBS Snapshots: {ec2_data['snapshots_total']} Total

🌐 Elastic IPs: {ec2_data['eips_total']} Total
  - ⚠️ UNASSOCIATED (Wasting Money): {ec2_data['eips_unassociated']}
"""
    except Exception as e:
        ec2_report = f"⚠️ Error fetching EC2 resources: {str(e)}\n"

    # Fetch S3
    try:
        s3_data = get_s3_resources()
        s3_text = "\n".join(s3_data) if s3_data else "  - None found."
        s3_report = f"\n🪣 S3 Buckets ({len(s3_data)} Total):\n{s3_text}\n"
    except Exception as e:
        s3_report = f"⚠️ Error fetching S3 resources: {str(e)}\n"

    # Construct the Email Body
    email_body = f"""
AWS Monthly Cost & Resource Report
==================================

{cost_report}
{ec2_report}
{s3_report}

----------------------------------
Automated by AWS Lambda & EventBridge
"""

    # Send Email via SMTP
    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = recipient_email
    msg['Subject'] = "Monthly AWS Account Report"
    msg.attach(MIMEText(email_body, 'plain'))
    
    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, app_password)
        server.send_message(msg)
        server.quit()
        print("Email sent successfully!")
        return {"statusCode": 200, "body": "Detailed email sent successfully"}
    except Exception as e:
        print(f"Failed to send email: {e}")
        return {"statusCode": 500, "body": f"Failed to send email: {e}"}